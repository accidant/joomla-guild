<?php
/**
 * Class ${NAME}
 *
 * Date: 09.09.13
 * Time: 15:00
 * @author Thomas Joußen <tjoussen@databay.de>
 */
//No direct access to this file
defined("_JEXEC") or die("Restricted Access");
JHTML::_('behavior.modal');
?>

<div id="wowranking">
	<ul>
		<li>World: <?php echo $params->ranking->world_rank; ?></li>
		<li>DE: <?php echo $params->ranking->area_rank; ?></li>
		<li>Realm: <?php echo $params->ranking->realm_rank; ?></li>
	</ul>
</div>