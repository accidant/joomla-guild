<?php

/**
 * Class modWowRaidPlannerHelper
 *
 * Date: 16.09.13
 * Time: 10:52
 * @author Thomas Joußen <tjoussen@databay.de>
 */ 
class modWowRaidPlannerHelper {

	public static function getRaids($params){

	}
}
