<?php
/**
 * Class ${NAME}
 *
 * Date: 16.09.13
 * Time: 10:54
 * @author Thomas Joußen <tjoussen@databay.de>
 */
//No direct access to this file
defined("_JEXEC") or die("Restricted Access");
?>